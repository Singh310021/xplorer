from django.contrib import admin
from .models import Adventure,Place,Activity,Status,Guide,Help

admin.site.register(Adventure)
admin.site.register(Place)
admin.site.register(Activity)
admin.site.register(Status)
admin.site.register(Guide)
admin.site.register(Help)


# Register your models here.
